(function($) {
    $(function() {
        $('.jkwhmhh_color_1').wpColorPicker();
        $('.jkwhmhh_color_2').wpColorPicker();
    });
})(jQuery);