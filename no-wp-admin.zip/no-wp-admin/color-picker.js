(function($) {
    // Add Color Picker to all inputs that have 'color-field' class
    $(function() {
        $('.jkwhmhh_color_1').wpColorPicker();
        $('.jkwhmhh_color_2').wpColorPicker();
    });
})(jQuery);